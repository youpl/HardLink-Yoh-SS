using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using System.Windows.Threading;
using HardlinkScanner.Core;

namespace HardlinkScanner;

public partial class MainWindow : Window
{
    private const string ConfigPath = "config.json";

    private readonly ObservableCollection<ScanRow> _rows = new();
    private CancellationTokenSource? _cts;

    public MainWindow()
    {
        InitializeComponent();
        ResultsGrid.ItemsSource = _rows;
        LoadConfigIntoUi(ScanConfig.Load(ConfigPath));
    }

    private void LoadConfigIntoUi(ScanConfig cfg)
    {
        YaraExeBox.Text = cfg.YaraExePath;
        RulesBox.Text = cfg.YaraRulesPath;
        PublishersBox.Text = string.Join(", ", cfg.TrustedPublishers);
        ExcludeTrustedCheck.IsChecked = cfg.ExcludeTrusted;
        OnlySuspiciousCheck.IsChecked = cfg.OnlyShowSuspicious;
    }

    private ScanConfig BuildConfigFromUi() => new()
    {
        YaraExePath = YaraExeBox.Text.Trim(),
        YaraRulesPath = RulesBox.Text.Trim(),
        TrustedPublishers = PublishersBox.Text
            .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .ToList(),
        ExcludeTrusted = ExcludeTrustedCheck.IsChecked == true,
        OnlyShowSuspicious = OnlySuspiciousCheck.IsChecked == true
    };

    private void BrowseBtn_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new Microsoft.Win32.OpenFolderDialog { Title = "Select drive or folder to scan" };
        if (dlg.ShowDialog() == true)
            TargetBox.Text = dlg.FolderName;
    }

    private void RulesBtn_Click(object sender, RoutedEventArgs e)
    {
        var dlg = new Microsoft.Win32.OpenFileDialog
        {
            Title = "Select YARA rules file",
            Filter = "YARA rules (*.yar;*.yara)|*.yar;*.yara|All files (*.*)|*.*"
        };
        if (dlg.ShowDialog() == true)
            RulesBox.Text = dlg.FileName;
    }

    private async void ScanBtn_Click(object sender, RoutedEventArgs e)
    {
        string target = TargetBox.Text.Trim();
        if (string.IsNullOrEmpty(target) || !Directory.Exists(target))
        {
            MessageBox.Show("Scan target does not exist.", "Hardlink Scanner",
                MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        var config = BuildConfigFromUi();
        config.Save(ConfigPath);

        _rows.Clear();
        LogBox.Clear();
        _cts = new CancellationTokenSource();
        SetScanning(true);
        Progress.IsIndeterminate = true;
        Log($"Scan started: {target}");

        var onRow = new Progress<ScanRow>(r => _rows.Add(r));
        var onProgress = new Progress<ScanProgress>(p =>
            StatusText.Text = $"{p.FilesScanned:N0} files · {p.GroupsFound:N0} groups · {Truncate(p.CurrentFile, 60)}");
        var onLog = new Progress<string>(Log);

        var engine = new ScanEngine(config);
        var token = _cts.Token;

        try
        {
            await Task.Run(() => engine.Run(target, onRow, onProgress, onLog, token), token);
        }
        catch (OperationCanceledException)
        {
            Log("Scan cancelled.");
        }
        catch (Exception ex)
        {
            Log($"ERROR: {ex.Message}");
        }
        finally
        {
            Progress.IsIndeterminate = false;
            SetScanning(false);
            StatusText.Text = $"Done · {_rows.Count:N0} flagged group(s)";
        }
    }

    private void StopBtn_Click(object sender, RoutedEventArgs e) => _cts?.Cancel();

    private void SetScanning(bool scanning)
    {
        ScanBtn.IsEnabled = !scanning;
        StopBtn.IsEnabled = scanning;
        BrowseBtn.IsEnabled = !scanning;
        RulesBtn.IsEnabled = !scanning;
    }

    private void Log(string line)
    {
        // Progress<T> callbacks already run on the UI thread; Dispatcher guard is for safety.
        if (!Dispatcher.CheckAccess()) { Dispatcher.Invoke(() => Log(line)); return; }
        LogBox.AppendText($"{DateTime.Now:HH:mm:ss}  {line}{Environment.NewLine}");
        LogBox.ScrollToEnd();
    }

    private static string Truncate(string s, int max)
        => string.IsNullOrEmpty(s) || s.Length <= max ? s : "…" + s[^max..];
}
