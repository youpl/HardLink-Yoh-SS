/*
 * Starter rules for Hardlink Scanner.
 * These are intentionally generic / heuristic — replace or extend them with your own.
 * Point the scanner at any .yar / .yara file via the UI or config.json.
 */

rule Suspicious_Hardlinked_Executable
{
    meta:
        description = "PE that is hard-linked into multiple locations (replace-bypass pattern)"
        author = "hardlink-scanner"
    strings:
        $mz = { 4D 5A }            // 'MZ'
    condition:
        $mz at 0
}

rule Contains_Injection_API_Names
{
    meta:
        description = "References classic process-injection APIs"
    strings:
        $a = "WriteProcessMemory" ascii wide
        $b = "VirtualAllocEx" ascii wide
        $c = "CreateRemoteThread" ascii wide
        $d = "NtUnmapViewOfSection" ascii wide
        $e = "SetWindowsHookEx" ascii wide
    condition:
        2 of them
}

rule Java_Agent_Or_Instrumentation
{
    meta:
        description = "Hints of a Java agent / bytecode instrumentation payload"
    strings:
        $a = "premain" ascii
        $b = "Instrumentation" ascii
        $c = "javaagent" ascii nocase
        $d = "Agent-Class" ascii
    condition:
        2 of them
}
