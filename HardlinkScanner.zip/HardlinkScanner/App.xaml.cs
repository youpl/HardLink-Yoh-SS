using System.Windows;

namespace HardlinkScanner;

public partial class App : Application
{
}
