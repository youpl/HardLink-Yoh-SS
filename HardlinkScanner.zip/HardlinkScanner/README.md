# Hardlink Scanner

A Windows (WPF / .NET 8) forensic tool that enumerates **NTFS hard-link groups** on a volume,
resolves every path that points at each underlying file, checks each file's **Authenticode
signature** (and *who* signed it), excludes **legitimate publishers** (Microsoft, etc.), and
runs **configurable YARA rules** against the linked files — all in a dark, scanner-style UI.

It's the defensive counterpart to the "replace-via-hardlink" trick: those bypasses hide from
the USN Journal, but the link still exists in the live filesystem while it's in use, so a
live MFT/filesystem scan surfaces it.

> **Scope note:** this reads the **live** filesystem. A hard link that has already been
> *deleted* leaves nothing here to find — recovering those needs `$LogFile`, VSS snapshots,
> or raw MFT carving, which this tool does not do.

---

## What it does

1. **Enumerate hard links.** Walks the target tree, and for every file whose NTFS link count
   is `> 1` it lists *all* of its paths via `FindFirstFileNameW` / `FindNextFileNameW`,
   de-duplicating groups by 64-bit file id. (Reparse points / junctions are skipped.)
2. **Verify signatures.** Each group's underlying file is checked with `WinVerifyTrust`
   (does the file actually match its signature and chain to a trusted root?) and the signer
   org/CN is extracted.
3. **Exclude legit files.** Files signed *and trusted* by a publisher in your whitelist
   (Microsoft by default) are filtered out — unless a YARA rule still hits.
4. **YARA.** Shells out to `yara64.exe` with your rules file. Fully configurable; no native
   binding to ship.

Suspicious rows (unsigned, signed-but-untrusted, non-whitelisted, or any YARA hit) are shown
in red.

## Requirements

- Windows 10/11, **NTFS** volume.
- **.NET 8 SDK** to build (`dotnet build`), or open in Visual Studio 2022.
- Runs **as Administrator** (the manifest forces this) so it can read protected paths and
  verify signatures everywhere.
- For YARA: download `yara64.exe` from the official YARA releases and either put it on `PATH`
  or set its full path in the UI / `config.json`. If it's missing, YARA is just skipped.

## Build & run

```powershell
cd HardlinkScanner
dotnet build -c Release
# then run the produced exe elevated:
.\bin\Release\net8.0-windows\HardlinkScanner.exe
```

## Configuration (`config.json`)

| Key                | Meaning                                                        |
|--------------------|----------------------------------------------------------------|
| `TrustedPublishers`| Signer substrings treated as legitimate and excluded.          |
| `YaraExePath`      | Path to `yara64.exe` (or just the name if on `PATH`).          |
| `YaraRulesPath`    | Path to your `.yar` / `.yara` rules file.                      |
| `ExcludeTrusted`   | Hide whitelisted/trusted files (YARA hits still surface).      |
| `OnlyShowSuspicious`| Hide everything that isn't flagged.                           |

The UI writes these back on each scan.

## Notes / honest caveats

- I couldn't compile or run this on Windows from where it was generated, so treat it as a
  solid, complete starting point — expect to build it and possibly smooth a rough edge
  (the `WinVerifyTrust` interop and the `FindFirstFileNameW` buffer handling are the most
  likely spots to want a second look).
- A full `C:\` walk is **O(all files)** — fast enough for triage but not instant. Scanning a
  specific folder is much quicker. If you want raw-MFT speed later, the enumeration layer
  (`HardlinkEnumerator`) is isolated and can be swapped for an MFT reader without touching the
  rest.
- All files in one hard-link group share identical bytes, so signature/YARA analysis is done
  once per group.
