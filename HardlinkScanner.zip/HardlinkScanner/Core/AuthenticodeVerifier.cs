using System.Runtime.InteropServices;
using System.Security.Cryptography.X509Certificates;

namespace HardlinkScanner.Core;

/// <summary>
/// Verifies a file's Authenticode signature with WinVerifyTrust (does the file actually match
/// its embedded signature and chain to a trusted root?) and separately extracts the signer name.
/// </summary>
public sealed class AuthenticodeVerifier
{
    private static readonly Guid WINTRUST_ACTION_GENERIC_VERIFY_V2 =
        new("00AAC56B-CD44-11d0-8CC2-00C04FC295EE");

    private const uint WTD_UI_NONE = 2;
    private const uint WTD_REVOKE_NONE = 0;
    private const uint WTD_CHOICE_FILE = 1;
    private const uint WTD_STATEACTION_VERIFY = 1;
    private const uint WTD_STATEACTION_CLOSE = 2;
    private const uint WTD_SAFER_FLAG = 0x100;

    private readonly IReadOnlyCollection<string> _trustedPublishers;

    public AuthenticodeVerifier(IReadOnlyCollection<string> trustedPublishers)
        => _trustedPublishers = trustedPublishers;

    public (SignatureState state, string signer, bool whitelisted) Inspect(string path)
    {
        string signer = TryGetSigner(path);
        bool hasSig = !string.IsNullOrEmpty(signer);

        if (!hasSig)
            return (SignatureState.Unsigned, "", false);

        bool trusted = VerifyTrust(path);
        bool whitelisted = trusted && IsWhitelisted(signer);

        return (trusted ? SignatureState.SignedTrusted : SignatureState.SignedUntrusted,
                signer, whitelisted);
    }

    private bool IsWhitelisted(string signer)
    {
        foreach (var p in _trustedPublishers)
            if (signer.IndexOf(p, StringComparison.OrdinalIgnoreCase) >= 0)
                return true;
        return false;
    }

    /// <summary>Pulls the signing certificate's subject (org / common name) if the file is signed.</summary>
    private static string TryGetSigner(string path)
    {
        try
        {
            using var cert = new X509Certificate2(X509Certificate.CreateFromSignedFile(path));
            // Prefer the Organisation, fall back to Common Name, then full subject.
            string? org = ExtractDnPart(cert.Subject, "O=");
            if (!string.IsNullOrEmpty(org)) return org!;
            string? cn = ExtractDnPart(cert.Subject, "CN=");
            return cn ?? cert.Subject;
        }
        catch
        {
            return ""; // not signed (or signature unreadable)
        }
    }

    private static string? ExtractDnPart(string subject, string prefix)
    {
        foreach (var raw in subject.Split(','))
        {
            string part = raw.Trim();
            if (part.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
                return part.Substring(prefix.Length).Trim().Trim('"');
        }
        return null;
    }

    private static bool VerifyTrust(string path)
    {
        var fileInfo = new WINTRUST_FILE_INFO
        {
            cbStruct = (uint)Marshal.SizeOf<WINTRUST_FILE_INFO>(),
            pcwszFilePath = path,
            hFile = IntPtr.Zero,
            pgKnownSubject = IntPtr.Zero
        };

        IntPtr pFile = Marshal.AllocHGlobal(Marshal.SizeOf<WINTRUST_FILE_INFO>());
        IntPtr pData = IntPtr.Zero;
        try
        {
            Marshal.StructureToPtr(fileInfo, pFile, false);

            var data = new WINTRUST_DATA
            {
                cbStruct = (uint)Marshal.SizeOf<WINTRUST_DATA>(),
                pPolicyCallbackData = IntPtr.Zero,
                pSIPClientData = IntPtr.Zero,
                dwUIChoice = WTD_UI_NONE,
                fdwRevocationChecks = WTD_REVOKE_NONE,
                dwUnionChoice = WTD_CHOICE_FILE,
                pFile = pFile,
                dwStateAction = WTD_STATEACTION_VERIFY,
                hWVTStateData = IntPtr.Zero,
                pwszURLReference = IntPtr.Zero,
                dwProvFlags = WTD_SAFER_FLAG,
                dwUIContext = 0,
                pSignatureSettings = IntPtr.Zero
            };

            pData = Marshal.AllocHGlobal(Marshal.SizeOf<WINTRUST_DATA>());
            Marshal.StructureToPtr(data, pData, false);

            Guid action = WINTRUST_ACTION_GENERIC_VERIFY_V2;
            uint result = WinVerifyTrust(IntPtr.Zero, action, pData);

            // Always close the state, regardless of result.
            data = Marshal.PtrToStructure<WINTRUST_DATA>(pData);
            data.dwStateAction = WTD_STATEACTION_CLOSE;
            Marshal.StructureToPtr(data, pData, false);
            WinVerifyTrust(IntPtr.Zero, action, pData);

            return result == 0; // 0 == ERROR_SUCCESS == trusted
        }
        catch
        {
            return false;
        }
        finally
        {
            if (pData != IntPtr.Zero) Marshal.FreeHGlobal(pData);
            Marshal.FreeHGlobal(pFile);
        }
    }

    [DllImport("wintrust.dll", ExactSpelling = true, SetLastError = false, CharSet = CharSet.Unicode)]
    private static extern uint WinVerifyTrust(IntPtr hwnd, [MarshalAs(UnmanagedType.LPStruct)] Guid pgActionID, IntPtr pWVTData);

    [StructLayout(LayoutKind.Sequential)]
    private struct WINTRUST_FILE_INFO
    {
        public uint cbStruct;
        [MarshalAs(UnmanagedType.LPWStr)] public string pcwszFilePath;
        public IntPtr hFile;
        public IntPtr pgKnownSubject;
    }

    [StructLayout(LayoutKind.Sequential)]
    private struct WINTRUST_DATA
    {
        public uint cbStruct;
        public IntPtr pPolicyCallbackData;
        public IntPtr pSIPClientData;
        public uint dwUIChoice;
        public uint fdwRevocationChecks;
        public uint dwUnionChoice;
        public IntPtr pFile;
        public uint dwStateAction;
        public IntPtr hWVTStateData;
        public IntPtr pwszURLReference;
        public uint dwProvFlags;
        public uint dwUIContext;
        public IntPtr pSignatureSettings;
    }
}
