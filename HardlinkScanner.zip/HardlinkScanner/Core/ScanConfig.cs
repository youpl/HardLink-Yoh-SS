using System.IO;
using System.Text.Json;

namespace HardlinkScanner.Core;

public sealed class ScanConfig
{
    public List<string> TrustedPublishers { get; set; } = new()
    {
        "Microsoft Corporation",
        "Microsoft Windows",
        "Microsoft Windows Hardware Compatibility Publisher",
        "Microsoft Windows Publisher"
    };

    public string YaraExePath { get; set; } = "yara64.exe";
    public string YaraRulesPath { get; set; } = "rules.yar";
    public bool ExcludeTrusted { get; set; } = true;
    public bool OnlyShowSuspicious { get; set; } = true;

    public static ScanConfig Load(string path)
    {
        try
        {
            if (File.Exists(path))
            {
                var json = File.ReadAllText(path);
                var cfg = JsonSerializer.Deserialize<ScanConfig>(json,
                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                if (cfg != null) return cfg;
            }
        }
        catch { /* fall back to defaults */ }
        return new ScanConfig();
    }

    public void Save(string path)
    {
        try
        {
            var json = JsonSerializer.Serialize(this, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(path, json);
        }
        catch { /* non-fatal */ }
    }
}
