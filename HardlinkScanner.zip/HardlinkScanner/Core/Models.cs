namespace HardlinkScanner.Core;

/// <summary>A set of paths that all resolve to the same underlying MFT entry (= the same bytes on disk).</summary>
public sealed class HardlinkGroup
{
    public ulong FileId { get; init; }
    public uint VolumeSerial { get; init; }
    public int LinkCount { get; init; }
    public List<string> Paths { get; init; } = new();

    /// <summary>The path we actually open for analysis. Any path in the group has identical content.</summary>
    public string PrimaryPath => Paths.Count > 0 ? Paths[0] : string.Empty;
}

public enum SignatureState
{
    Unsigned,
    SignedUntrusted, // signed but WinVerifyTrust did not establish trust (revoked / broken chain / tampered)
    SignedTrusted
}

/// <summary>The result of inspecting one hardlink group's underlying file.</summary>
public sealed class ScanRow
{
    public int GroupId { get; set; }
    public int LinkCount { get; set; }
    public string PathsJoined { get; set; } = string.Empty;
    public string PrimaryPath { get; set; } = string.Empty;

    public SignatureState Signature { get; set; }
    public string Signer { get; set; } = "";          // publisher / subject org or CN
    public bool IsWhitelisted { get; set; }            // signer is in the trusted-publisher list

    public string YaraMatches { get; set; } = "";      // comma-separated rule names, empty if none

    /// <summary>True when this row warrants attention: not a whitelisted/trusted file, or a YARA hit.</summary>
    public bool Suspicious =>
        !string.IsNullOrEmpty(YaraMatches)
        || Signature == SignatureState.Unsigned
        || Signature == SignatureState.SignedUntrusted
        || !IsWhitelisted;

    public string SignatureText => Signature switch
    {
        SignatureState.SignedTrusted => "Signed (trusted)",
        SignatureState.SignedUntrusted => "Signed (UNTRUSTED)",
        _ => "Unsigned"
    };
}
