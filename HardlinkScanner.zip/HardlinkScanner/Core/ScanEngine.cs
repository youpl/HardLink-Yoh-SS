namespace HardlinkScanner.Core;

public sealed class ScanProgress
{
    public int FilesScanned { get; set; }
    public int GroupsFound { get; set; }
    public string CurrentFile { get; set; } = "";
}

/// <summary>
/// Ties the pieces together: enumerate hard-link groups, then for each group's underlying file
/// run signature inspection and (optionally) YARA, applying the whitelist / suspicious filters.
/// All UI updates are pushed back through IProgress callbacks so this stays UI-agnostic.
/// </summary>
public sealed class ScanEngine
{
    private readonly ScanConfig _config;

    public ScanEngine(ScanConfig config) => _config = config;

    public void Run(
        string root,
        IProgress<ScanRow> onRow,
        IProgress<ScanProgress> onProgress,
        IProgress<string> onLog,
        CancellationToken ct)
    {
        var verifier = new AuthenticodeVerifier(_config.TrustedPublishers);
        var yara = new YaraScanner(_config.YaraExePath, _config.YaraRulesPath);
        if (!yara.Enabled)
            onLog.Report($"[YARA disabled] {yara.DisabledReason}");
        else
            onLog.Report($"[YARA] rules: {_config.YaraRulesPath}");

        var enumerator = new HardlinkEnumerator();
        var prog = new ScanProgress();
        int groupId = 0;

        foreach (var group in enumerator.Enumerate(
                     root,
                     file => { prog.FilesScanned++; prog.CurrentFile = file;
                               if (prog.FilesScanned % 250 == 0) onProgress.Report(Clone(prog)); },
                     err => onLog.Report(err),
                     ct))
        {
            ct.ThrowIfCancellationRequested();
            prog.GroupsFound++;
            groupId++;

            var (state, signer, whitelisted) = verifier.Inspect(group.PrimaryPath);
            var yaraMatches = yara.Enabled ? yara.Scan(group.PrimaryPath) : new List<string>();

            var row = new ScanRow
            {
                GroupId = groupId,
                LinkCount = group.LinkCount,
                PrimaryPath = group.PrimaryPath,
                PathsJoined = string.Join(Environment.NewLine, group.Paths),
                Signature = state,
                Signer = signer,
                IsWhitelisted = whitelisted,
                YaraMatches = string.Join(", ", yaraMatches)
            };

            // Apply filters. A YARA hit always surfaces, even on whitelisted files.
            bool hasYara = yaraMatches.Count > 0;
            if (_config.ExcludeTrusted && whitelisted && !hasYara)
            {
                onProgress.Report(Clone(prog));
                continue;
            }
            if (_config.OnlyShowSuspicious && !row.Suspicious)
            {
                onProgress.Report(Clone(prog));
                continue;
            }

            onRow.Report(row);
            onProgress.Report(Clone(prog));
        }

        onProgress.Report(Clone(prog));
        onLog.Report($"Done. {prog.FilesScanned:N0} files inspected, {prog.GroupsFound:N0} hard-link groups found.");
    }

    private static ScanProgress Clone(ScanProgress p) => new()
    {
        FilesScanned = p.FilesScanned,
        GroupsFound = p.GroupsFound,
        CurrentFile = p.CurrentFile
    };
}
