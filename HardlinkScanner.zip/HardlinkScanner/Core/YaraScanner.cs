using System.Diagnostics;
using System.IO;

namespace HardlinkScanner.Core;

/// <summary>
/// Thin wrapper around the YARA command-line scanner. We shell out to yara64.exe rather than
/// bind libyara, so rules stay fully configurable (just point at any .yar / .yara file) and
/// there's no native dependency to ship. If the binary or rules file is missing, scanning is
/// silently disabled and every file reports "no matches".
/// </summary>
public sealed class YaraScanner
{
    private readonly string _yaraExe;
    private readonly string _rulesPath;
    public bool Enabled { get; }
    public string? DisabledReason { get; }

    public YaraScanner(string yaraExe, string rulesPath)
    {
        _yaraExe = yaraExe;
        _rulesPath = rulesPath;

        if (string.IsNullOrWhiteSpace(yaraExe) || !BinaryResolvable(yaraExe))
        {
            Enabled = false;
            DisabledReason = $"YARA binary not found: '{yaraExe}'";
        }
        else if (string.IsNullOrWhiteSpace(rulesPath) || !File.Exists(rulesPath))
        {
            Enabled = false;
            DisabledReason = $"YARA rules file not found: '{rulesPath}'";
        }
        else
        {
            Enabled = true;
        }
    }

    /// <summary>Returns the names of matching rules (empty if none / disabled).</summary>
    public List<string> Scan(string targetFile, int timeoutMs = 15000)
    {
        var matches = new List<string>();
        if (!Enabled) return matches;

        try
        {
            var psi = new ProcessStartInfo
            {
                FileName = _yaraExe,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                UseShellExecute = false,
                CreateNoWindow = true
            };
            // yara [options] <rules_file> <target>
            psi.ArgumentList.Add("-f");          // fast matching
            psi.ArgumentList.Add(_rulesPath);
            psi.ArgumentList.Add(targetFile);

            using var p = Process.Start(psi);
            if (p == null) return matches;

            string stdout = p.StandardOutput.ReadToEnd();
            if (!p.WaitForExit(timeoutMs))
            {
                try { p.Kill(true); } catch { /* ignore */ }
                return matches;
            }

            foreach (var line in stdout.Split('\n'))
            {
                string trimmed = line.Trim();
                if (trimmed.Length == 0) continue;
                // Output format: "<rule_name> <path>"
                int sp = trimmed.IndexOf(' ');
                string rule = sp > 0 ? trimmed[..sp] : trimmed;
                if (!matches.Contains(rule)) matches.Add(rule);
            }
        }
        catch
        {
            // swallow: a single file failing YARA shouldn't abort the scan
        }

        return matches;
    }

    private static bool BinaryResolvable(string exe)
    {
        if (File.Exists(exe)) return true;
        // search PATH
        string? pathVar = Environment.GetEnvironmentVariable("PATH");
        if (pathVar == null) return false;
        foreach (var dir in pathVar.Split(Path.PathSeparator))
        {
            try
            {
                if (File.Exists(Path.Combine(dir, exe))) return true;
            }
            catch { /* ignore malformed PATH entries */ }
        }
        return false;
    }
}
