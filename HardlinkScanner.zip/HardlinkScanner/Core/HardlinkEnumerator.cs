using System.IO;
using System.Text;
using Microsoft.Win32.SafeHandles;

namespace HardlinkScanner.Core;

/// <summary>
/// Walks a directory tree and yields every group of files that share a single MFT entry
/// (i.e. true NTFS hard links, link count &gt; 1). Reparse points (symlinks/junctions) are
/// skipped so we neither loop nor wander off-volume.
///
/// Note: this reads the LIVE filesystem. A hard link that was already deleted leaves no
/// trace here — recovering those requires $LogFile / VSS / MFT carving, which is out of scope.
/// </summary>
public sealed class HardlinkEnumerator
{
    private readonly HashSet<ulong> _seen = new();

    /// <param name="root">e.g. "C:\" or any subfolder.</param>
    /// <param name="onFileCounted">Invoked for every file inspected, for progress.</param>
    public IEnumerable<HardlinkGroup> Enumerate(
        string root,
        Action<string>? onFileCounted,
        Action<string>? onError,
        CancellationToken ct)
    {
        string volumeRoot = GetVolumeRoot(root); // "C:" with no trailing slash
        var stack = new Stack<string>();
        stack.Push(root);

        while (stack.Count > 0)
        {
            ct.ThrowIfCancellationRequested();
            string dir = stack.Pop();

            IEnumerable<string> subDirs = Array.Empty<string>();
            IEnumerable<string> files = Array.Empty<string>();

            try
            {
                var di = new DirectoryInfo(dir);
                if ((di.Attributes & FileAttributes.ReparsePoint) != 0)
                    continue; // don't descend into junctions / symlinks

                subDirs = Directory.EnumerateDirectories(dir);
                files = Directory.EnumerateFiles(dir);
            }
            catch (Exception ex)
            {
                onError?.Invoke($"Skip dir '{dir}': {ex.Message}");
                continue;
            }

            foreach (var sub in subDirs)
                stack.Push(sub);

            foreach (var file in files)
            {
                ct.ThrowIfCancellationRequested();
                onFileCounted?.Invoke(file);

                HardlinkGroup? group = null;
                try
                {
                    group = TryBuildGroup(file, volumeRoot);
                }
                catch (Exception ex)
                {
                    onError?.Invoke($"Skip file '{file}': {ex.Message}");
                }

                if (group != null)
                    yield return group;
            }
        }
    }

    private HardlinkGroup? TryBuildGroup(string file, string volumeRoot)
    {
        using SafeFileHandle h = NativeMethods.CreateFileW(
            file,
            NativeMethods.FILE_READ_ATTRIBUTES,
            NativeMethods.FILE_SHARE_READ | NativeMethods.FILE_SHARE_WRITE | NativeMethods.FILE_SHARE_DELETE,
            IntPtr.Zero,
            NativeMethods.OPEN_EXISTING,
            NativeMethods.FILE_FLAG_BACKUP_SEMANTICS,
            IntPtr.Zero);

        if (h.IsInvalid)
            return null;

        if (!NativeMethods.GetFileInformationByHandle(h, out var info))
            return null;

        if (info.NumberOfLinks <= 1)
            return null; // ordinary file, not a hard link

        ulong fileId = ((ulong)info.FileIndexHigh << 32) | info.FileIndexLow;
        // De-dup: a group with N links will be hit N times during the walk.
        lock (_seen)
        {
            if (!_seen.Add(fileId))
                return null;
        }

        var paths = EnumerateLinkNames(file, volumeRoot);
        if (paths.Count == 0)
            paths.Add(file);

        return new HardlinkGroup
        {
            FileId = fileId,
            VolumeSerial = info.VolumeSerialNumber,
            LinkCount = (int)info.NumberOfLinks,
            Paths = paths
        };
    }

    /// <summary>Returns every full path that points at the same file, using FindFirstFileNameW.</summary>
    private static List<string> EnumerateLinkNames(string anyPath, string volumeRoot)
    {
        var result = new List<string>();
        uint len = 0;
        var sb = new StringBuilder(260);

        IntPtr handle = NativeMethods.FindFirstFileNameW(anyPath, 0, ref len, sb);
        if (handle == NativeMethods.INVALID_HANDLE_VALUE)
        {
            int err = Marshal.GetLastWin32Error();
            if (err == NativeMethods.ERROR_MORE_DATA)
            {
                sb.EnsureCapacity((int)len);
                handle = NativeMethods.FindFirstFileNameW(anyPath, 0, ref len, sb);
            }
            if (handle == NativeMethods.INVALID_HANDLE_VALUE)
                return result;
        }

        try
        {
            do
            {
                // sb holds a path relative to the volume root, starting with '\'.
                result.Add(volumeRoot + sb.ToString());

                len = 0;
                sb.Clear();
                sb.EnsureCapacity(260);
                if (!NativeMethods.FindNextFileNameW(handle, ref len, sb))
                {
                    int err = Marshal.GetLastWin32Error();
                    if (err == NativeMethods.ERROR_MORE_DATA)
                    {
                        sb.EnsureCapacity((int)len);
                        if (!NativeMethods.FindNextFileNameW(handle, ref len, sb))
                            break;
                        result.Add(volumeRoot + sb.ToString());
                        continue;
                    }
                    break; // ERROR_HANDLE_EOF or other -> done
                }
            } while (true);
        }
        finally
        {
            NativeMethods.FindClose(handle);
        }

        return result;
    }

    private static string GetVolumeRoot(string path)
    {
        // "C:\Users\..." -> "C:"
        string full = Path.GetFullPath(path);
        string r = Path.GetPathRoot(full) ?? full; // "C:\"
        return r.TrimEnd('\\', '/');
    }
}
